import {Component, OnInit} from 'angular2/core';




@Component({
  template: `
    <h2>Inicio</h2>
      <p>debemos cargar la pagina de inicio abajo al pulsar sobre inicio</p>
    `,
})



export class HeroesComponent{
}
