import {Component} from 'angular2/core';

@Component({
  template: `

    <h3>Suscripciones</h3>
      <p>debemos cargar abajo una web</p>
    `
})

export class DashboardComponent{
}
